package login;

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import javax.naming.spi.DirStateFactory;

public class Conexao {

    private String url = "jdbc:postgresql://localhost/MTP";
    //usuario postgres
    private String usuario = "postgres";
    //senha
    private String senha = "jvpdne587363";
    //variavel que guarda a conexao
    private Connection conn;

    public Conexao() {
        conectar();

    }

    void conectar() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
        Properties props = new Properties();
        props.setProperty("user", this.usuario);
        props.setProperty("password", this.senha);
        try {
            this.conn = DriverManager.getConnection(this.url, props);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String Login(String email, String senha) {
        try {
            PreparedStatement ps = this.conn
                    .prepareStatement("SELECT id, nome FROM pessoa WHERE email =? AND  senha= ?");
            ps.setString(1, email);// é colocado no primeiro sinal de (?) da linha 27.
            ps.setString(2, senha);// é colocado no segundo sinal de (?) da linha 27.
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {//next anda uma casa adiante da atual

                return rs.getString(2);
            } else {
                return null;
            }
        } catch (Exception e) {
                e.printStackTrace();
        }
        return null;
    }
    
        public String Cadastro(String email,String login, String senha,String cidade_estado) {
        try {
            PreparedStatement ps = this.conn
                    .prepareStatement("INSERT INTO public.pessoa(login,nome, email, senha, cidade_estado)");

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {//next anda uma casa adiante da atual

                return rs.getString(2);
            } else {
                return null;
            }
        } catch (Exception e) {
                e.printStackTrace();
        }
        return null;
    }
}

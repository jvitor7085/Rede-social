
package login;

import java.sql.PreparedStatement;


public class LeitorArquivo {

}
